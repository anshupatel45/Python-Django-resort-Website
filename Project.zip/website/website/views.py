from django.shortcuts import render

from .models import ContactForm
from django.contrib import messages
def contact_us(request):
    if request.method =="POST":
        prod = ContactForm()
        prod.message = request.POST.get('message')
        prod.name = request.POST.get('name')
        prod.email = request.POST.get('email')
        prod.subject = request.POST.get('subject')
       
        prod.save()
        messages.success(request, "Product Added Successfully")
        return render(request, 'contact.html')
    
    else:
        messages.success(request, "Product not Added Successfully")
        return render(request,'contact.html')
    
