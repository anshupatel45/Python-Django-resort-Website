STEP 1: Install virtual environment and then create virtual environment.

STEP 2: Install python and Django in virtual environment.

STEP 3: Open the project file in editor (VS code).

STEP 4: Now activate virtual environment.

STEP 5: Open the Command Prompt and type workon <Environment name> to activate the environment.

STEP 6: Now run pip command and download Django , mysqlclient, pillow

STEP 7: Now run the xampp server to connect database.(add name in database which is written in settings) 

STEP 8: Now run the 'python manage.py migrate' command.

STEP 9: Now write 'python manage.py runserver' in command prompt.

STEP 10: Now in browser type 127.0.0.0.8000.

STEP 11: As the website is fully dynamic add the data in admin panel. 


FOR ADMIN PANEL

Run the 'python manage.py createsuperuser' command and then fill the following details.
then reapeat step 9.

Now in browser type 127.0.0.0.8000/admin/ and enter username and password . 