from django.urls import path
from . import views

from .views import TableList, BookingList,BookingView




urlpatterns =[
     

     path('',views.index),
     path('home1/',views.home1,name="index"),
     path('blog/',views.blog,name="blog"),
     path('main/',views.main,name="main"),
     path('rooms/',views.rooms,name="rooms"),
     path('services/',views.services,name="services"),
     path('about/',views.about,name="about"),
     path('contactus/',views.contact_us,name="contactus"),
     
     path('home/',views.home, name="home"),
     path('login/', views.login_user, name ='login'),
     path('logout/', views.logout_user, name='logout'),
     path('register/', views.register_user, name='register'),
     path('edit_profile/', views.edit_profile, name='edit_profile'),
     path('change_password/', views.change_password, name='change_password'),
     path('table_list/',TableList.as_view(),name="tablelist"),
     path('booking_list/',BookingList.as_view(),name="bookinglist"),
     path('book/',BookingView.as_view(),name="bookingview"),
     
     ]