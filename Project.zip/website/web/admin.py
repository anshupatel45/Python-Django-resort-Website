from django.contrib import admin

from web.models import room_C1, room_C2, room_C3, event_1, scroller, blog_0, Navbar, about_us, Hotel_name, address, service_0, developer, reservation, testimonial
from .models import Table,Booking


admin.site.register(room_C1)
admin.site.register(room_C2)
admin.site.register(room_C3)
admin.site.register(event_1)
admin.site.register(scroller)
admin.site.register(blog_0)
admin.site.register(Navbar)
admin.site.register(about_us)
admin.site.register(Hotel_name)
admin.site.register(address)
admin.site.register(service_0)
admin.site.register(developer)
admin.site.register(reservation)
admin.site.register(testimonial)


admin.site.register(Table)
admin.site.register(Booking)







# Register your models here.
