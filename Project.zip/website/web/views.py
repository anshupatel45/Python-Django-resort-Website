from email import message
from django.http import HttpResponse
from django.shortcuts import render
from .models import event_1, room_C1 , room_C2, room_C3, scroller, blog_0, Navbar, about_us, Hotel_name, address, service_0, developer, reservation, ContactForm, testimonial
from django.core.mail import send_mass_mail
from django.conf import settings
from django.views.generic import ListView

def contact_us(request):
    ddd = Navbar.objects.all()
    iii = address.objects.all()
    kkk = developer.objects.all()
    ggg = reservation.objects.all()
    
    
    if request.method =="POST":
         email= request.POST.get('email')
         subject = request.POST.get('subject')
         content = request.POST.get('message')
         name = request.POST.get('name')
         msg="Thanks for contacting us, Our team will look after your mail!!"
         
         msg2 = 'Customer Name: ' + name + '/n Customer email:' + email + '/n Description: '+ content

         message1=(subject,msg2,'anshuproject@gmail.com',['panshu771@gmail.com'])
         message2=('Neejanand',msg,'anshuproject@gmail.com',[email])
         send_mass_mail((message1,message2),fail_silently=False)
         return render(request,'contact.html',{'tile':'send an email', 'iii':iii, 'ddd':ddd, 'ggg':ggg, 'kkk':kkk,})
        #HttpResponse("your data has been submitted")
         
        # send_mail (
         #     subject,
          #    content,
           #   settings.EMAIL_HOST_USER,
            #  [email,'panshu771@gmail.com']
          # )
          
     
        # return render(request,'contact.html',{'tile':'send an email', 'ddd':ddd})
           
    else:
         return render(request,'contact.html',{'tile':'send an email', 'iii':iii, 'ddd':ddd,'ggg':ggg, 'kkk':kkk,})


def index(request):
     rms = room_C1.objects.all()
     xxx = room_C2.objects.all()
     yyy = room_C3.objects.all()
     aaa = event_1.objects.all()
     ccc = scroller.objects.all()
     ddd = Navbar.objects.all()
     fff = about_us.objects.all()
     hhh = Hotel_name.objects.all()
     iii = address.objects.all()
     kkk = developer.objects.all()
     ggg = reservation.objects.all()
     mmm = testimonial.objects.all()
     return render(request,'index.html',{ 'mmm':mmm,'iii':iii,'rms' : rms, 'xxx' : xxx, 'yyy':yyy, 'aaa':aaa , 'ccc':ccc, 'ddd':ddd, 'fff':fff, 'ggg':ggg, 'hhh':hhh, 'kkk':kkk})
    
def home1(request):
     rms = room_C1.objects.all()
     xxx = room_C2.objects.all()
     yyy = room_C3.objects.all()
     aaa = event_1.objects.all()
     ccc = scroller.objects.all()
     ddd = Navbar.objects.all()
     fff = about_us.objects.all()
     hhh = Hotel_name.objects.all()
     iii = address.objects.all()
     kkk = developer.objects.all()
     ggg = reservation.objects.all()
     mmm = testimonial.objects.all()
     return render(request,'index.html',{ 'mmm':mmm, 'iii':iii, 'ggg':ggg, 'kkk':kkk,'hhh':hhh,'rms' : rms, 'xxx' : xxx, 'yyy':yyy, 'aaa':aaa , 'ccc':ccc, 'ddd':ddd, 'fff':fff})


def blog(request):
     eee = blog_0.objects.all()
     ddd = Navbar.objects.all()
     ggg = reservation.objects.all()
     iii = address.objects.all()
     kkk = developer.objects.all()
     ggg = reservation.objects.all()
     return render(request,'blog.html',{ 'iii':iii,'ggg':ggg, 'kkk':kkk,'eee':eee, 'ddd':ddd})



def main(request):
     return render(request,'main.html')



def rooms(request):
     rms = room_C1.objects.all()
     xxx = room_C2.objects.all()
     yyy = room_C3.objects.all()
     ddd = Navbar.objects.all()
     ggg = reservation.objects.all()
     iii = address.objects.all()
     kkk = developer.objects.all()
     ggg = reservation.objects.all()
     return render(request,'rooms.html',{ 'iii':iii,'ggg':ggg, 'kkk':kkk, 'rms' : rms, 'xxx' : xxx, 'yyy':yyy, 'ddd':ddd })



def services(request):
     ddd = Navbar.objects.all()
     ggg = reservation.objects.all()
     iii = address.objects.all()
     jjj = service_0.objects.all()
     kkk = developer.objects.all()
     ggg = reservation.objects.all()
     return render(request,'services.html', { 'iii':iii,'ggg':ggg, 'kkk':kkk,'ddd':ddd, 'jjj':jjj})



def about(request):
     aaa = event_1.objects.all()
     ddd = Navbar.objects.all()
     fff = about_us.objects.all()
     ggg = reservation.objects.all()
     iii = address.objects.all()
     kkk = developer.objects.all()
     ggg = reservation.objects.all()
     return render(request,'about.html',{ 'iii':iii,'ggg':ggg, 'kkk':kkk, 'aaa':aaa , 'ddd':ddd, 'fff':fff})

#contact form



from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash 
from django.contrib.auth.forms import UserCreationForm, UserChangeForm, PasswordChangeForm
from django.contrib import messages 
from .forms import SignUpForm, EditProfileForm 
# Create your views here.
def home(request): 
	return render(request, 'home.html', {})

def login_user (request):
	if request.method == 'POST': #if someone fills out form , Post it 
		username = request.POST['username']
		password = request.POST['password']
		user = authenticate(request, username=username, password=password)
		if user is not None:# if user exist
			login(request, user)
			messages.success(request,('Youre logged in'))
			return redirect('home') #routes to 'home' on successful login  
		else:
			messages.success(request,('Error logging in'))
			return redirect('login') #re routes to login page upon unsucessful login
	else:
		return render(request, 'login.html', {})

def logout_user(request):
	logout(request)
	messages.success(request,('Youre now logged out'))
	return redirect('home')

def register_user(request):
	if request.method =='POST':
		form = SignUpForm(request.POST)
		if form.is_valid():
			form.save()
			username = form.cleaned_data['username']
			password = form.cleaned_data['password1']
			user = authenticate(username=username, password=password)
			login(request,user)
			messages.success(request, ('Youre now registered'))
			return redirect('home')
	else: 
		form = SignUpForm() 

	context = {'form': form}
	return render(request, 'register.html', context)

def edit_profile(request):
	if request.method =='POST':
		form = EditProfileForm(request.POST, instance= request.user)
		if form.is_valid():
			form.save()
			messages.success(request, ('You have edited your profile'))
			return redirect('home')
	else: 		#passes in user information 
		form = EditProfileForm(instance= request.user) 

	context = {'form': form}
	return render(request, 'edit_profile.html', context)
	#return render(request, 'authenticate/edit_profile.html',{})



def change_password(request):
	if request.method =='POST':
		form = PasswordChangeForm(data=request.POST, user= request.user)
		if form.is_valid():
			form.save()
			update_session_auth_hash(request, form.user)
			messages.success(request, ('You have edited your password'))
			return redirect('home')
	else: 		#passes in user information 
		form = PasswordChangeForm(user= request.user) 

	context = {'form': form}
	return render(request, 'change_password.html', context)

# new added
from unicodedata import category
from urllib import request
from django.http import HttpResponse
from django.shortcuts import render
import datetime
from .models import Table,Booking
from django.views.generic import ListView, FormView
from .forms import AvailibilityForm

# def index(request):
#     return render(request,"index.html")


# Create your views here.
def check_availability(table,check_in,check_out):
    avail_list=[]
    booking_list=Booking.objects.filter(table=table)
    for booking in booking_list:
        if booking.check_in > check_out or booking.check_out < check_in:
            avail_list.append(True)
        else:
            avail_list.append(False)   
    return all(avail_list)         

class TableList(ListView):
    model=Table

class BookingList(ListView):
    model=Booking

#New added  

    
class BookingView(FormView):
    form_class=AvailibilityForm
    template_name='availibility_form.html'

    def form_valid(self,form):
        data=form.cleaned_data
        table_list=Table.objects.filter(category=data['table_category'])
        available_table=[]
        for table in table_list:
            if check_availability(table,data['check_in'],data['check_out']):
                available_table.append(table)

        if len(available_table)>0:
            table = available_table[0]
            booking = Booking.objects.create(
                user = self.request.user,
                table = table,
                check_in= data['check_in'],
                check_out=data['check_out']
            )
            booking.save()

            return HttpResponse("Your Room is successfully booked")
        else:
            return HttpResponse("This category Rooms are not available")    
