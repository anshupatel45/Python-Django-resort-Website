import datetime
import os
from django.db import models

# Create your models here.

class room_C1(models.Model):
     roomimg = models.ImageField(upload_to='uploads',blank=True, null=True)
     roomname = models.CharField(max_length=20,blank=True, null=True)
     roomprice = models.TextField(max_length=500,blank=True, null=True)
     
     
class room_C2(models.Model):
     roomimg = models.ImageField(upload_to='uploads',blank=True, null=True)
     roomname = models.CharField(max_length=20,blank=True, null=True)
     roomprice = models.TextField(max_length=500,blank=True, null=True)
     
class room_C3(models.Model):
     roomimg = models.ImageField(upload_to='uploads',blank=True, null=True)
     roomname = models.CharField(max_length=20,blank=True, null=True)
     roomprice = models.TextField(max_length=500,blank=True, null=True)
     
class event_1(models.Model):
     eventimg = models.ImageField(upload_to='uploads',blank=True, null=True)
     eventname = models.CharField(max_length=50,blank=True, null=True)
     eventdescription = models.CharField(max_length=1000,blank=True, null=True)
     
class service_0(models.Model):
     serviceimg = models.ImageField(upload_to='uploads',blank=True, null=True)
     servicename = models.CharField(max_length=50,blank=True, null=True)
     servicedescription = models.CharField(max_length=1000,blank=True, null=True)
     
class blog_0(models.Model):
     blogimg = models.ImageField(upload_to='uploads',blank=True, null=True)
     blogdate = models.CharField(max_length=50,blank=True, null=True)
     blogname = models.CharField(max_length=50,blank=True, null=True)
     blogdescription = models.CharField(max_length=1000,blank=True, null=True)
     
class scroller(models.Model):
     scrollerimg = models.ImageField(upload_to='uploads',blank=True, null=True)
     
class about_us(models.Model):
     aboutimg = models.ImageField(upload_to='uploads',blank=True, null=True)
     aboutname = models.CharField(max_length=50,blank=True, null=True)
     aboutsubname = models.CharField(max_length=50,blank=True, null=True)
     aboutdescription = models.CharField(max_length=1000,blank=True, null=True)
     
class Navbar(models.Model):
     Nname = models.CharField(max_length=50)
     href = models.CharField(max_length=50)
     
class developer(models.Model):
     devname = models.CharField(max_length=50)
     devhref = models.CharField(max_length=50)     
     addname = models.CharField(max_length=50)     
     addhref = models.CharField(max_length=50) 
     
         
class reservation(models.Model):
     mobile= models.TextField(max_length=500,blank=True, null=True)
     resname1 = models.CharField(max_length=50)
     reshref1 = models.CharField(max_length=50)     
     resname2 = models.CharField(max_length=50)     
     reshref2 = models.CharField(max_length=50)     
     
class Hotel_name(models.Model):
     hotelname = models.CharField(max_length=50)
     hoteldescription = models.CharField(max_length=50)
     
     
class address(models.Model):
     address1 = models.CharField(max_length=50)
     address2 = models.CharField(max_length=50)
     Googlecode = models.CharField(max_length=50)
     
class ContactForm(models.Model):
    message= models.CharField(max_length=200)
    name= models.CharField(max_length=100)
    email= models.EmailField()
    subject= models.CharField(max_length=50)
    
    class meta:
        db_table="web_contactform"
    
    
class testimonial(models.Model):
    Tname= models.CharField(max_length=100)
    Tsubname= models.CharField(max_length=50)
    Tmessage= models.CharField(max_length=200)
     
     
def filepath(request,filename):
    old_filename = filename
    timenow= datetime.datetime.now().strftime('%d%m%Y%H:%M:%S')
    filename="%s%s" % (timenow, old_filename)
    return os.path.join('uploads/', filename)     


# new add
from unicodedata import category
from django.db import models
from django.conf import settings

class BookTable(models.Model):
    name=models.CharField(max_length=100)
    email=models.EmailField(max_length=100)
    phone=models.CharField(max_length=10)
    date=models.DateField()
    time=models.TimeField()
    people=models.IntegerField()
    message=models.TextField(max_length=100)

    class meta:
        db_table="ansu"
     
class Contactus(models.Model):
    name=models.CharField(max_length=100)
    email=models.EmailField(max_length=100)
    subject=models.TextField(max_length=100)
    message=models.TextField(max_length=100)
    
    class meta:
        db_table="ansu"


# Create your models here.

class Table(models.Model):
    TABLE_CATEGORIES= (
        ('YAC', 'AC'),
        ('NYC', 'NON-AC'),
        ('DEL', 'DELUX'),
        ('KING', 'KING'),        
        ('QUE', 'QUEEN'),        

    )
    number = models.IntegerField()
    category=models.CharField(max_length=10, choices=TABLE_CATEGORIES)
    chairs=models.IntegerField()
    capacity=models.IntegerField()
    def __str__(self):
        return f'{self.number}.{self.category} with {self.chairs} for {self.capacity} people'

class Booking(models.Model):
    user=models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    table=models.ForeignKey(Table, on_delete=models.CASCADE)
    check_in=models.DateTimeField()
    check_out=models.DateTimeField()

    def __str__(self):
        return f'{self.user} has booked {self.table} from {self.check_in} to {self.check_out}'

class name(models.Model):
    name=models.CharField(max_length=10)